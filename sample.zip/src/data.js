
export const data = [
	{
		id: 1,
		title: "Bahama-Mama",
		searchTerm: "rum",
		image: "./img/bahama-mama.jpg"
	},
	{
		id: 2,
		title: "Bloody Mary",
		searchTerm: "vodka",
		image: "./img/bloody-mary.jpg"
	},
	{
		id: 3,
		title: "Blue Hawaii",
		searchTerm: "rum",
		image: "./img/blue-hawaii.jpg"
	},
	{
		id: 4,
		title: "Blue Lagoon",
		searchTerm: "vodka",
		image: "./img/blue-lagoon.jpg"
	},
	{
		id: 5,
		title: "Caipirinha",
		searchTerm: "rum",
		image: "./img/caipirinha.jpg"
	},
	{
		id: 6,
		title: "Cosmopolitan",
		searchTerm: "vodka",
		image: "./img/cosmopolitan.jpg"
	},
	{
		id: 7,
		title: "Cuba-Libre",
		searchTerm: "rum",
		image: "./img/cuba-libre.jpg"
	},
	{
		id: 8,
		title: "Dirty Martini",
		searchTerm: "gin",
		image: "./img/dirty-martini.jpg"
	},
	{
		id: 9,
		title: "Hiroshima",
		searchTerm: "sambuca",
		image: "./img/hiroshima.jpg"
	},
	{
		id: 10,
		title: "Kamikaze",
		searchTerm: "vodka",
		image: "./img/kamikaze.jpg"
	},
	{
		id: 11,
		title: "Long-Island Iced Tea",
		searchTerm: "tequila",
		image: "./img/long-island-iced-tea.jpg"
	},
	{
		id: 12,
		title: "Mai Tai",
		searchTerm: "rum",
		image: "./img/mai-tai.jpg"
	},
	{
		id: 13,
		title: "Margarita",
		searchTerm: "tequila",
		image: "./img/margarita.jpg"
	},
	{
		id: 14,
		title: "Mint Julep",
		searchTerm: "whiskey",
		image: "./img/mint-julep.jpg"
	},
	{
		id: 15,
		title: "Mojito",
		searchTerm: "rum",
		image: "./img/mojito.jpg"
	},
	{
		id: 16,
		title: "Pina Colada",
		searchTerm: "rum",
		image: "./img/pina-colada.jpg"
	},
	{
		id: 17,
		title: "Pisco Sour",
		searchTerm: "pisco",
		image: "./img/pisco-sour.jpg"
	},
	{
		id: 18,
		title: "Salty Dog",
		searchTerm: "vodka",
		image: "./img/salty-dog.jpg"
	},
	{
		id: 19,
		title: "Screwdriver",
		searchTerm: "vodka",
		image: "./img/screwdriver.jpg"
	},
	{
		id: 20,
		title: "Strawberry Daiquiri",
		searchTerm: "rum",
		image: "./img/strawberry-daiquiri.jpg"
	},
	{
		id: 21,
		title: "Strawberry Mojito",
		searchTerm: "rum",
		image: "./img/strawberry-mojito.jpg"
	},
	{
		id: 22,
		title: "Blue Tahoe",
		searchTerm: "champagne",
		image: "./img/tahoe-blue.jpg"
	},
	{
		id: 23,
		title: "Tequila Sunrise",
		searchTerm: "tequila",
		image: "./img/tequila-sunrise.jpg"
	},
	{
		id: 24,
		title: "Whiskey Sour",
		searchTerm: "whiskey",
		image: "./img/whiskey-sour.jpg"
	}
]