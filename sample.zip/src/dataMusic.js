export const data = [
	{
		id: 1,
		title: 'Friday: Jazz Band "King Louie"',
		image: "./img/performance.png",
		description: "The best, favorite, familiar from childhood jazz tunes of real jazz arranged by world famous musicians."
	},
	{
		id: 2,
		title: 'Saturday: live music with Andy Doug!',
		image: "./img/man.jpg",
		description: "The student of the great B.B. King did not let his teacher down! Do not expect that there will be at least one seat left in the hall!"
	},
	{
		id: 3,
		title: 'Sunday: this evening for you romantic Mr. Leon.',
		image: "./img/musician.jpg",
		description: "Find out what his saxophone is capable of! The best time to propose 💍 or confess 💘. There are no indifferent people!"
	},
	{
		id: 4,
		title: 'Wednesday: live sound and the best compositions for you',
		image: "./img/singer.png",
		description: "Our best aspiring stars sing famous jazz compositions 🎵, including at your request!"
	}
]
